import UIKit
import RxSwift

let dispose = DisposeBag()
// 问题1: 下面的输出结果
let ignore = PublishSubject<String>()
ignore.ignoreElements()
    .subscribe { _ in
        print("ignore subscribe")
    }.disposed(by: dispose)

ignore.onNext("1")
ignore.onNext("2")
ignore.onNext("3")
ignore.onCompleted()
//A :1,2,3,ignore subscribe
//B :1,2,3
//C :ignore subscribe
//D :(无任何打印)


// 问题2:
Observable.of("1","2","3","1","1","2","2","3","3","4","5","6")
    .distinctUntilChanged()
    .subscribe(onNext: {
        print(($0))
    }, onError: nil, onCompleted: {
        print("complete")
    }).disposed(by: dispose)
//A : 1 2 3 1 1 2 2 3 3 4 5 6
//B : 1 2 3 4 5 6 complete
//C : 1 2 3 1 2 3 4 5 6 complete
//D : 1 2 3 1 2 3 4 5 6

// 问题3:
Observable.of(0, 1, 2, 3, 4, 5, 6)
    .skipWhile { $0 % 2 == 0 }
    .subscribe(onNext: { print($0)})
    .disposed(by: dispose)
//A : 0 2 4 6
//B : 1 3 5
//C : 1 2 3 4 5 6
//D : 0

// 问题4:
Observable.of(0, 1, 2, 3, 4, 5, 6)
    .filter { $0 % 2 == 0 }
    .subscribe(onNext: { print($0)})
    .disposed(by: dispose)
//A : 0 2 4 6
//B : 1 3 5
//C : 1 2 3 4 5 6
//D : 0

// 问题5:
let aSeq = PublishSubject<String>()
let bSeq = PublishSubject<String>()
aSeq.skipUntil(bSeq)
    .subscribe(onNext: { print($0)})
    .disposed(by: dispose)
aSeq.onNext("1")
aSeq.onNext("2")
aSeq.onNext("3")
bSeq.onNext("4")
aSeq.onNext("5")
aSeq.onNext("6")
aSeq.onNext("7")
bSeq.onNext("8")
//A: 123
//B: 1234
//C: 567
//D: 5678
//E: 12345678

// 问题6:
let numbers = Observable<Int>.create { observer in
    observer.onNext(1)
    observer.onNext(2)
    observer.onCompleted()
    return Disposables.create()
    }.share()
numbers.subscribe(onNext: {
    print("\($0)")
}, onCompleted: {
    print("completed!")
}).disposed(by: dispose)
numbers.subscribe(onNext: {
    print("\($0)")
},onCompleted: {
    print("completed!")
}).disposed(by: dispose)

//A: 1 2
//B: 1 2 completed!
//C: 1 2 completed! completed!
//D: 1 2 completed! 1 2 completed!

// 问题7:
Observable.of(1,2,3,4,5)
    .throttle(RxTimeInterval.seconds(1), scheduler: MainScheduler.instance)
    .subscribe(onNext: {print($0)})
    .disposed(by: dispose)

Observable.of(1,2,3,4,5)
    .debounce(RxTimeInterval.seconds(1), scheduler: MainScheduler.instance)
    .subscribe(onNext: {print($0)})
    .disposed(by: dispose)
//A: 1 2 3 4 5 1 2 3 4 5
//B: 1 2 3 4 5
//C: 5 1
//D: 1 5


// 问题8:
public func delay(by delayTime: TimeInterval, qosClass: DispatchQoS.QoSClass? = nil,
                  _ closure: @escaping () -> Void) {
    let dispatchQueue = qosClass != nil ? DispatchQueue.global(qos: qosClass!) : .main
    dispatchQueue.asyncAfter(deadline: DispatchTime.now() + delayTime, execute: closure)
}

let disposeBag = DisposeBag()
let observable = Observable<Int>.interval(DispatchTimeInterval.seconds(1), scheduler: MainScheduler.instance)
    .publish().refCount()
let firstSubscribe = observable.subscribe(onNext: {
    print("first next = \($0)")
})
delay(by: 3, {
    print("dispose at 3 seconds")
    firstSubscribe.disposed(by: disposeBag)
})

delay(by: 6, {
    print("subscribe again at 6 seconds")
    observable.subscribe(onNext: {
        print("next = \($0)")
    }).disposed(by: disposeBag)
})

//A: 
//first next = 0
//first next = 1
//first next = 2
//dispose at 3 seconds
//first next = 3
//first next = 4
//first next = 5
//subscribe again at 6 seconds

//B:
//first next = 0
//first next = 1
//first next = 2
//dispose at 3 seconds

//C:
//first next = 0
//first next = 1
//first next = 2
//dispose at 3 seconds
//first next = 3
//first next = 4
//first next = 5
//subscribe again at 6 seconds
//first next = 6
//ext = 6
//first next = 7
//ext = 7

//D:
//first next = 0
//first next = 1
//first next = 2
//dispose at 3 seconds
//subscribe again at 6 seconds

//问题9:
var count = 1
let deferredSequence = Observable<String>.deferred {
    print("Creating \(count)")
    count += 1
        
    return Observable.create { observer in
        print("Observable")
        observer.onNext("AAA")
        observer.onNext("BBB")
        observer.onNext("CCC")
        return Disposables.create()
    }
}
    
deferredSequence
    .subscribe(onNext: { print($0) })
    .disposed(by: disposeBag)
    
deferredSequence
    .subscribe(onNext: { print($0) })
    .disposed(by: disposeBag)

//A:
//Creating 1
//Observable
///AAA
//BBB
//CCC
//Creating 2
//Observable
//AAA
//BBB
//CCC


//B:
//Creating 1
//Observable
//AAA
//BBB
//CCC
//Creating 1
//Observable
//AAA
//BBB
//CCC

//C:
//Creating 1
//Observable
//AAA
//BBB
//CCC


//D:
//Creating 1
//Creating 2


//问题10:
let disposeBag = DisposeBag()
Observable.of("A", "B", "C", "D")
.do(onNext: { print("do:", $0) }, onError: { print("error:", $0) }, onCompleted: { print("Completed")  })
.subscribe(onNext: { print("next:",$0) })
.disposed(by: disposeBag)

//A:
//do: A
//do: B
//do: C
//do: D
//next: A
//next: B
//next: C
//next: D
//Completed

//B:
//do: A
//next: A
//do: B
//next: B
//do: C
//next: C
//do: D
//next: D


//C:
//do: A
//next: A
//do: B
//next: B
//do: C
//next: C
//do: D
//next: D
//Completed

//D:
//next: A
//next: B
//next: C
//next: D
//Completed
