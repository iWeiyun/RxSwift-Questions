//
//  ViewController.swift
//  RxSwiftDemo
//
//  Created by Gemini on 2019/8/19.
//  Copyright © 2019 Gemini. All rights reserved.
//

import UIKit
import RxSwift

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let disposeBag = DisposeBag()
        Observable.of("A", "B", "C", "D")
        .do(onNext: { print("do:", $0) }, onError: { print("error:", $0) }, onCompleted: { print("Completed")  })
        .subscribe(onNext: { print("next:",$0) })
        .disposed(by: disposeBag)
    }
}

public func delay(by delayTime: TimeInterval, qosClass: DispatchQoS.QoSClass? = nil,
                  _ closure: @escaping () -> Void) {
    let dispatchQueue = qosClass != nil ? DispatchQueue.global(qos: qosClass!) : .main
    dispatchQueue.asyncAfter(deadline: DispatchTime.now() + delayTime, execute: closure)
}

